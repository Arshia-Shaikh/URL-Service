
# Shortly
A URL Shortening Service Coded In **Django.**
 
 [Tutorial](https://youtu.be/LaeAiXOc_3Q)
 
## Initial Commit

1. Authentication
2. Custom URL
3. Random URL Generation
4. Number Of Visits
5. Unlimited URL Shortening
6. Can Use In Your Project
7. Added Delete
 