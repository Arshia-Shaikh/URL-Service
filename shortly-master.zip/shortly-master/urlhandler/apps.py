from django.apps import AppConfig


class UrlhandlerConfig(AppConfig):
    name = 'urlhandler'
